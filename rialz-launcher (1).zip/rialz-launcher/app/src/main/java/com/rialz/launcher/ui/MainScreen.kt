package com.rialz.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rialz.launcher.data.McVersion
import com.rialz.launcher.data.MinecraftApi
import com.rialz.launcher.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(settings: SettingsStore) {
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Rialz Launcher") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("▶") },
                    label = { Text("Versi") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("⚙") },
                    label = { Text("Pengaturan") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                0 -> VersionTab()
                1 -> SettingsTab(settings)
            }
        }
    }
}

@Composable
private fun VersionTab() {
    var versions by remember { mutableStateOf<List<McVersion>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var onlyRelease by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        try {
            versions = withContext(Dispatchers.IO) { MinecraftApi.fetchVersions() }
        } catch (e: Exception) {
            error = e.message ?: "Gagal memuat versi"
        } finally {
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Hanya release", Modifier.weight(1f))
            Switch(checked = onlyRelease, onCheckedChange = { onlyRelease = it })
        }
        Spacer(Modifier.height(8.dp))

        when {
            loading -> CircularProgressIndicator()
            error != null -> Text("Error: $error", color = MaterialTheme.colorScheme.error)
            else -> {
                val list = if (onlyRelease) versions.filter { it.type == "release" } else versions
                LazyColumn {
                    items(list) { v ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(v.id, style = MaterialTheme.typography.titleMedium)
                                Text(v.type, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsTab(settings: SettingsStore) {
    var ram by remember { mutableFloatStateOf(settings.maxRamMb.toFloat()) }
    var name by remember { mutableStateOf(settings.offlineName) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("RAM maksimal: ${ram.toInt()} MB")
        Slider(
            value = ram,
            onValueChange = { ram = it },
            onValueChangeFinished = { settings.maxRamMb = ram.toInt() },
            valueRange = 1024f..8192f,
            steps = 6
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                settings.offlineName = it
            },
            label = { Text("Nama pemain (offline)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
