package com.rialz.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import com.rialz.launcher.data.SettingsStore
import com.rialz.launcher.ui.MainScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = SettingsStore(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface {
                    MainScreen(settings)
                }
            }
        }
    }
}
