# Rialz Launcher (fondasi)

Fondasi launcher Minecraft Android. Saat ini baru berisi:
- Daftar versi Minecraft dari manifest resmi Mojang (`MinecraftApi.kt`)
- Pengaturan RAM dan nama pemain offline (`SettingsStore.kt`, `MainScreen.kt`)

## Cara membuka
1. Install Android Studio (Ladybug atau lebih baru).
2. File > Open, pilih folder `rialz-launcher`.
3. Tunggu Gradle sync selesai, lalu Run di emulator atau HP dengan USB debugging.

## Belum ada (langkah berikutnya)
1. Unduh client JAR, libraries, dan assets per versi.
2. Login Microsoft / Xbox dan mode offline lengkap.
3. Manajemen instance per versi dan per modpack.
4. Instalasi loader (Fabric, Forge, NeoForge, Quilt).
5. Instalasi modpack `.mrpack` (Modrinth) dan `manifest.json` (CurseForge).
6. Runtime Java dan renderer di Android (bagian native, paling berat).

## Build APK tanpa Android Studio (GitHub Actions)
Workflow ada di `.github/workflows/build-apk.yml`. Setiap push, atau tombol Run workflow secara manual, akan menghasilkan APK yang bisa diunduh di tab Actions > Build APK > Artifacts.
