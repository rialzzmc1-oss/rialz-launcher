package com.rialz.launcher.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Satu versi Minecraft dari manifest resmi Mojang. */
data class McVersion(
    val id: String,
    val type: String,
    val url: String
)

object MinecraftApi {
    private const val MANIFEST_URL =
        "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

    /** Mengambil daftar versi. Panggil dari background thread. */
    fun fetchVersions(): List<McVersion> {
        val json = get(MANIFEST_URL)
        val arr = JSONObject(json).getJSONArray("versions")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            McVersion(
                id = o.getString("id"),
                type = o.getString("type"),
                url = o.getString("url")
            )
        }
    }

    private fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 15_000
        try {
            if (conn.responseCode !in 200..299) {
                error("HTTP ${conn.responseCode} saat mengambil $url")
            }
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
