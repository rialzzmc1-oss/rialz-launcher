package com.rialz.launcher.data

import android.content.Context

/** Pengaturan launcher yang disimpan lokal. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("rialz_settings", Context.MODE_PRIVATE)

    /** Alokasi RAM untuk game dalam MB. */
    var maxRamMb: Int
        get() = prefs.getInt(KEY_RAM, 2048)
        set(value) = prefs.edit().putInt(KEY_RAM, value).apply()

    /** Nama pemain untuk mode offline. */
    var offlineName: String
        get() = prefs.getString(KEY_NAME, "Player") ?: "Player"
        set(value) = prefs.edit().putString(KEY_NAME, value).apply()

    private companion object {
        const val KEY_RAM = "max_ram_mb"
        const val KEY_NAME = "offline_name"
    }
}
